"use strict";(()=>{var e={};e.id=2,e.ids=[2],e.modules={3524:e=>{e.exports=require("@prisma/client")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},2464:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>x,patchFetch:()=>h,requestAsyncStorage:()=>g,routeModule:()=>m,serverHooks:()=>f,staticGenerationAsyncStorage:()=>y});var a={};t.r(a),t.d(a,{GET:()=>u,dynamic:()=>l,revalidate:()=>d});var o=t(9303),n=t(8716),i=t(670),c=t(7070),s=t(2331);function p(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;"):""}let l="force-dynamic",d=3600;async function u(){try{let e=await s._.product.findMany({where:{price:{gt:0}},take:8e3,orderBy:{isFeatured:"desc"}}),r=new Map,t=1;e.forEach(e=>{let a=e.category||"Бытовая техника";r.has(a)||r.set(a,t++)});let a=new Date().toISOString().replace(/\.\d{3}Z$/,"+03:00"),o="https://simona-bt.ru",n=`<?xml version="1.0" encoding="UTF-8"?>
`;for(let t of(n+=`<!DOCTYPE yml_catalog SYSTEM "shops.dtd">
<yml_catalog date="${a}">
  <shop>
    <name>СИМОНА</name>
    <company>Салоны премиальной бытовой техники \xabСИМОНА\xbb</company>
    <url>${o}</url>
    <currencies>
      <currency id="RUR" rate="1"/>
    </currencies>
    <categories>
`,r.forEach((e,r)=>{n+=`      <category id="${e}">${p(r)}</category>
`}),n+=`    </categories>
    <offers>
`,e)){let e=r.get(t.category||"Бытовая техника")||1,a=t.inStock||t.stockCount>0,i=[];try{i=JSON.parse(t.imagesJson||"[]")}catch{i=[]}n+=`      <offer id="${p(t.id)}" available="${a}">
        <url>${o}/product/${p(t.slug)}</url>
        <price>${t.price}</price>
`,t.oldPrice&&t.oldPrice>t.price&&(n+=`        <oldprice>${t.oldPrice}</oldprice>
`),n+=`        <currencyId>RUR</currencyId>
        <categoryId>${e}</categoryId>
`,i.length>0&&i.slice(0,5).forEach(e=>{n+=`        <picture>${p(e)}</picture>
`}),n+=`        <name>${p(t.name)}</name>
        <vendor>${p(t.brand)}</vendor>
        <vendorCode>${p(t.sku)}</vendorCode>
        <description>${p(t.description?.replace(/<[^>]*>/g,"").slice(0,1e3))}</description>
        <delivery>true</delivery>
        <pickup>true</pickup>
        <store>${t.stockBelinskogo15>0?"true":"false"}</store>
        <param name="Наличие на складе Коминтерна 27">${t.stockKominterna>0?"Есть":"Под заказ"}</param>
        <param name="Экспозиция в салоне">${t.stockBelinskogo15>0?"ул. Белинского, 15":"Нет"}</param>
      </offer>
`}return n+=`    </offers>
  </shop>
</yml_catalog>
`,new c.NextResponse(n,{headers:{"Content-Type":"application/xml; charset=utf-8","Cache-Control":"public, s-maxage=3600, stale-while-revalidate=7200"}})}catch(e){return console.error("YML feed generation error:",e),new c.NextResponse("Internal Server Error",{status:500})}}let m=new o.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/feeds/yandex.xml/route",pathname:"/api/feeds/yandex.xml",filename:"route",bundlePath:"app/api/feeds/yandex.xml/route"},resolvedPagePath:"C:\\Users\\trash\\Documents\\antigravity\\simona-bt_NEW\\app\\api\\feeds\\yandex.xml\\route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:g,staticGenerationAsyncStorage:y,serverHooks:f}=m,x="/api/feeds/yandex.xml/route";function h(){return(0,i.patchFetch)({serverHooks:f,staticGenerationAsyncStorage:y})}},2331:(e,r,t)=>{t.d(r,{_:()=>o});var a=t(3524);let o=globalThis.prisma??new a.PrismaClient({log:["error"]})}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[948,972],()=>t(2464));module.exports=a})();